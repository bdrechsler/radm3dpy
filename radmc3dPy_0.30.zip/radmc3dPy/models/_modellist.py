from . import lines_nlte_lvg_1d_1
from . import ppdisk
#from . import ppdisk_acc
from . import simple_1
from . import spher1d_1
from . import spher2d_1
from . import test_scattering_1
from . import ppdisk_amr

_model_list = ['lines_nlte_lvg_1d_1','ppdisk','simple_1','spher1d_1','spher2d_1','test_scattering_1','ppdisk_amr']
